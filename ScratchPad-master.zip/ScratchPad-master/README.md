# Scratchpad

This is a repo to build an app on phonegap, thanks to karatebuilderboy for scratch-to-phonegap.
